CREATE TABLE biblio.log_livres (
    idLog INTEGER auto_increment NOT NULL,
    idLivre INTEGER NOT NULL,
    type_operation ENUM ('insert', 'update', 'delete') NOT NULL,
    date_operation TIMESTAMP NOT NULL,
    CONSTRAINT log_livres_PK PRIMARY KEY (idLog)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

CREATE TRIGGER insert_livres
AFTER
INSERT ON livres FOR EACH ROW
INSERT INTO log_livres
SET idLivre = NEW.idLivre,
    type_operation = 'insert',
    date_operation = now();

CREATE TRIGGER delete_livres
AFTER DELETE ON livres FOR EACH ROW
INSERT INTO log_livres
SET idLivre = OLD.idLivre,
    type_operation = 'delete',
    date_operation = now();

CREATE TRIGGER update_livres
AFTER
UPDATE ON livres FOR EACH ROW
INSERT INTO log_livres
SET idLivre = OLD.idLivre,
    type_operation = 'update',
    date_operation = now();