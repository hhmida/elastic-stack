@app.route('/search', methods=['GET', 'POST'])
def search():
    res = None
    if request.method == 'POST':
        saisie = request.form['search'].strip()
        if saisie=="":
            query ={
                "query": {
                    "match_all": {}
                }
            }
        elif request.form['champ']=='tous':
            query = {
                "query": {
                    "multi_match": {
                        "query": saisie,
                        "fields": ["titre", "auteur"],
                        "fuzziness": 2 if request.form.get('fuzzy') else 0
                    }
                }
            }            
        else:
            query ={
                "query": {
                    "match": {
                        "{}".format(request.form['champ']):{
                            "query": saisie,
                            "fuzziness": 2 if request.form.get('fuzzy') else 0
                        }
                    }
                }
            }
            
        res = es.search(index="livres2", **query)
        
    return render_template("search.html", res=res)